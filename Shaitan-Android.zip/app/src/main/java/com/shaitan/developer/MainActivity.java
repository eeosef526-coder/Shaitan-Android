package com.shaitan.developer;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    LinearLayout mainLayout;

    int RED = Color.rgb(220, 20, 40);
    int BLACK = Color.rgb(8, 8, 8);
    int WHITE = Color.WHITE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(BLACK);
        getWindow().setNavigationBarColor(BLACK);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(BLACK);

        mainLayout = new LinearLayout(this);
        mainLayout.setOrientation(LinearLayout.VERTICAL);
        mainLayout.setPadding(20, 25, 20, 30);
        mainLayout.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        scroll.addView(mainLayout);
        setContentView(scroll);

        // عنوان التطبيق
        TextView title = new TextView(this);
        title.setText("آلمـطـور شـيطـآن");
        title.setTextSize(30);
        title.setTextColor(RED);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(10, 30, 10, 15);

        mainLayout.addView(title);

        // وصف التطبيق
        TextView subtitle = new TextView(this);
        subtitle.setText("مرحباً بك في عالم التطوير والذكاء الاصطناعي");
        subtitle.setTextSize(15);
        subtitle.setTextColor(WHITE);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(5, 10, 5, 30);

        mainLayout.addView(subtitle);

        // الأقسام الرئيسية
        addButton("🤖  مساعد الذكاء الاصطناعي");
        addButton("💻  أدوات المطور");
        addButton("🐍  تعلم لغة Python");
        addButton("📱  معلومات الجهاز");
        addButton("🔐  أساسيات الأمن السيبراني");
        addButton("⚙️  إعدادات التطبيق");
        addButton("ℹ️  حول التطبيق");
    }

    private void addButton(String text) {

        TextView button = new TextView(this);

        button.setText(text);
        button.setTextSize(18);
        button.setTextColor(WHITE);
        button.setTypeface(null, Typeface.BOLD);
        button.setGravity(Gravity.CENTER);
        button.setPadding(15, 22, 15, 22);

        GradientDrawable shape = new GradientDrawable();
        shape.setColor(Color.rgb(15, 15, 15));
        shape.setCornerRadius(18);
        shape.setStroke(2, RED);

        button.setBackground(shape);

        LinearLayout.LayoutParams params =
                new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                );

        params.setMargins(0, 10, 0, 10);

        mainLayout.addView(button, params);

        button.setOnClickListener(v ->
                Toast.makeText(
                        this,
                        "سيتم تطوير هذا القسم قريباً",
                        Toast.LENGTH_SHORT
                ).show()
        );
    }
}